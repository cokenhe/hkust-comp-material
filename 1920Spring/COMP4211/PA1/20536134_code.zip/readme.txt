You may find all the code in 20536134_code.ipynb.
All the cells should be find except GridSearchCV in task 4.
You may need quite a lot of time to search the hyperparameters.

So I have attached the trained model here.
Please load the model for the code in task 4.