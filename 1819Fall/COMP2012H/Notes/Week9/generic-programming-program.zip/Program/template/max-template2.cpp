template <class T>      /* File: max-template2.cpp */
T my_max(const T& a, const T& b)
{
    return (a > b) ? a : b;
}
