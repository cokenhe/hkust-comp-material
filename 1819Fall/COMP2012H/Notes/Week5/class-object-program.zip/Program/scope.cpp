int height = 10;
class Weird 
{
    short height; 
    Weird() { height = 5; }
};
