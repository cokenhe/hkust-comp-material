class Cell
{
    int info;
    Cell* next;
};
