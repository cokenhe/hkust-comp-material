void print-label-pbr(const UPerson& uperson) { uperson.print(); }
void print-label-pbp(const UPerson* uperson) { uperson->print(); }
