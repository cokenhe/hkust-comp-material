class UPerson 
{
  public:
    UPerson(const string n, const string a, Department d);
    virtual ~UPerson() { }
    ...
};
