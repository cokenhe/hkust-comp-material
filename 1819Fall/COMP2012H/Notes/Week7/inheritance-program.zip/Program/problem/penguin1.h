class Penguin : public Bird  /* File: penguin1.h */
{
    ...
  public:
    ...
    void swim();
    void catch_fish();
};
