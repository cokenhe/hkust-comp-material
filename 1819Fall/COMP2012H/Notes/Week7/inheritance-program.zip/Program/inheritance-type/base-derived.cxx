class Derived : public Base { ... }
Base base;
Derived derived;
