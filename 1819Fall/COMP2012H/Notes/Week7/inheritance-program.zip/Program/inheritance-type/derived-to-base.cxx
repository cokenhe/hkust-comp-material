base = derived;     // Slicing
Base* b = &derived; // Can't use derived-class specific members
Base& b = derived;  // Can't use derived-class specific members
