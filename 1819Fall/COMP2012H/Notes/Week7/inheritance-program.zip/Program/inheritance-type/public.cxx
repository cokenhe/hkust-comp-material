class Student: public UPerson { ... }
