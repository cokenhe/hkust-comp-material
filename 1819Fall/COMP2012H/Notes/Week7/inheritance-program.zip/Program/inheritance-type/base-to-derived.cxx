derived = base;     // Unless you define such conversion 
Derived* d = &base; // No such conversion
Derived& d = base;  // No such conversion
