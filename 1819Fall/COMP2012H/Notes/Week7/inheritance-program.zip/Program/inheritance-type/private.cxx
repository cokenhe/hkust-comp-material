class Student: private UPerson { ... }
