class Student: protected UPerson { ... }
