/* File: personal-asset.cpp */
Personal_Asset::Personal_Asset(const string& date)
     : purchase_date(date) { }

void Personal_Asset::set_purchase_date(const string& date)
     { purchase_date = date; }

double Personal_Asset::compute_net_worth() const
     { return /* What? */ }
