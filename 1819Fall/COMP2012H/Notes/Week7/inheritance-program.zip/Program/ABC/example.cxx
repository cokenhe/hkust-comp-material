Personal_Asset p_asset("1997/07/01");        // Error
Bank_Acc_Asset b_asset("2000/01/01", 100.0); // Ok
