// index:   01234567890123456789012345678901234567890123456789
string s = "The rain in Spain stays mainly in the plain.";
string s1 = s.substr(1, 2);
string s2 = s.substr(9, 8);
string s3 = s1 + " is " + s2;
cout << s3 << endl;     // Output: he is in Spain
