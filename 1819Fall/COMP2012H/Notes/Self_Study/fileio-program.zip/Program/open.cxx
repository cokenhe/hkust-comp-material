#include <fstream>
// [1] Use a special form of ifstream/ofstream constructor
ifstream ifs("input.txt");
ofstream ofs("output.txt");

// [2] Use the default form of ifstream/ofstream constructor, 
//     and then their open() member function
ifstream ifs; ifs.open("input.txt"); 
ofstream ofs; ofs.open("output.txt");
