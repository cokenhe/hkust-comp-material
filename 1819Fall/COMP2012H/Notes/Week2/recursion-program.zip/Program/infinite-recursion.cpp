int factorial(int n)
{
    // Forget the base case!
    return n * factorial(n-1);
}
