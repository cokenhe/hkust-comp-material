Word_Pair(const char* x, const char* y) { w1 = x; w2 = y; }
