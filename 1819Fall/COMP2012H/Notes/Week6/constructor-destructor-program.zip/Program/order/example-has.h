/* File: example-has.h */
class B { ... }; 

class A
{
  private:
    B my_b;

  public:
  // Declaration of public members or functions
};
