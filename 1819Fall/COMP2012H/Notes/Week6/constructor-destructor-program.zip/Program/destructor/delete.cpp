main( )  /* File: delete.cpp */
{
    Stack* p = new Stack(9); // A dynamically allocated stack object
    int* q = new int [100]; // A dynamically allocated array of integers
    delete p;           // delete an object
    delete [ ] q;       // delete an array of objects
    p = 0;              // It is a good practice to set a pointer to NULL
    q = 0;              // when it is not pointing to anything
}
