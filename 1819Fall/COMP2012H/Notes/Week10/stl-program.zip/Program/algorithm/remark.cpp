// Create a Greater_Than function object g
Greater_Than g(350);
p = find_if( x.begin(), x.end(), g );
