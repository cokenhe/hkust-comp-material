int a; /* bfile.cpp */
int func() {
  a = 20;
  return a;
}
