/* File: point.h */

struct Point
{
    double x;
    double y;
};
