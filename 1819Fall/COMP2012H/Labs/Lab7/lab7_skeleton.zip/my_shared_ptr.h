#ifndef MY_SHARED_PTR_H_
#define MY_SHARED_PTR_H_

#include <utility>
using std::move;

template <typename T>
class my_shared_ptr {
public:
	/*******************************
	 * Constructors and Destructor *
	 *******************************/

	// Default Constructor, p is empty.
	my_shared_ptr() {}

	// Parameterized Constructor, takes ownership of p.
	/*
	 * Note: There exists the issue of 2 my_shared_ptrs thinking they have single and separate ownership of the same object.
	 * We ignore this for the sake of lab simplicity, as it is a complex problem to solve.
	 */
	my_shared_ptr(T* p) {}

	// Copy Constructor, shares p.
	my_shared_ptr(const my_shared_ptr<T>& x) {}

	// Move Constructor, x becomes empty.
	my_shared_ptr(my_shared_ptr<T>&& x) : my_shared_ptr() {
		swap(x); // this is Default Constructed, then this and x swap contents. x will have its Destructor called at the end of this function scope.
	}

	// Destructor, decrement use_count and deallocate memory if this is the last my_shared_ptr.
	~my_shared_ptr() {}



	/************************
	 * Operator Overloading *
	 ************************/

	// Copy Assignment Operator, shares p.
	// Bonus Task: Implement with C++11 Move-Semantics by reusing the Copy Constructor and Move Assignment Operator.
	my_shared_ptr& operator=(const my_shared_ptr<T>& x) {}

	// Move Assignment Operator, x becomes empty.
	my_shared_ptr& operator=(my_shared_ptr<T>&& x) {
		this->swap(x); // Swap previous contents with x, which will have its Destructor called at the end of this function scope.
		return *this;
	}

	// Dereference Operators.
	T& operator*() const {}

	T* operator->() const {}



	/*********************
	 * Utility Functions *
	 *********************/

	T* get_pointer() const { return p; }
	int get_count() const { return ((p == nullptr)? 0 : *use_count); }

	bool unique() const {}

	// Remember to decrement use_count and deallocate memory if this is the last my_shared_ptr.
	// Bonus Task: Implement with C++11 Move-Semantics.
	void reset() {}

	void reset(T* p) {}

	// Hint: You may use this function when attempting the Bonus Task.
	void swap(my_shared_ptr<T>& x) {}



private:
	T* p;
	unsigned int* use_count;
};

#endif /* MY_SHARED_PTR_H_ */
