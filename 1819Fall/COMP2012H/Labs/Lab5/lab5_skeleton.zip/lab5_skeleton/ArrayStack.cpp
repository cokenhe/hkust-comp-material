#include "ArrayStack.h"

ArrayStack::ArrayStack(unsigned int startingArraySize) {}
ArrayStack::ArrayStack(const ArrayStack& arrayStack) {};
ArrayStack::~ArrayStack() {};

ArrayStack& ArrayStack::operator=(const ArrayStack& arrayStack) {

}

int ArrayStack::peek() const {

}

void ArrayStack::push(int element) {

}

int ArrayStack::pop() {

}

void ArrayStack::popAll(int data[]) {

}
