#include "ArrayQueue.h"

ArrayQueue::ArrayQueue(unsigned int startingArraySize) {}
ArrayQueue::ArrayQueue(const ArrayQueue& arrayQueue) {};
ArrayQueue::~ArrayQueue() {};

ArrayQueue& ArrayQueue::operator=(const ArrayQueue& arrayQueue) {

}

int ArrayQueue::peek() const {

}

void ArrayQueue::push(int element) {

}

int ArrayQueue::pop() {

}

void ArrayQueue::popAll(int data[]) {

}
