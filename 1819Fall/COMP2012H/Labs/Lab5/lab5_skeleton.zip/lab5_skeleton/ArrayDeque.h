#ifndef ARRAYDEQUE_H_
#define ARRAYDEQUE_H_

// Note: Think carefully about which base class to derive from, in order to maximize code reuse.


#endif /* ARRAYDEQUE_H_ */
