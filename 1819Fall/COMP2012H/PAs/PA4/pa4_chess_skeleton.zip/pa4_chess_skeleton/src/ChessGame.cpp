#include "ChessGame.h"

/******************************
 * Constructor and Destructor *
 ******************************/

ChessGame::ChessGame() {}
ChessGame::~ChessGame() {}



/********************
 * ChessBoard State *
 ********************/

King* ChessGame::getPlayerKing(Player player) const {}
bool ChessGame::hasValidMoves(Player player) const {}
void ChessGame::calculateValidMoves(ChessPiece* chessPiece, bool validMoves[8][8]) const {}
void ChessGame::promotePawn(Pawn* pawn) {}



/******************
 * ChessGame Flow *
 ******************/

void ChessGame::processUserInput(int row, int col) {}
void ChessGame::selectChessPiece(int row, int col) {}
void ChessGame::moveSelectedChessPiece(int row, int col) {}
void ChessGame::nextPlayerTurn() {}



/**************
 * Graphic UI *
 **************/

GameWindow* ChessGame::get_game_window() const {}
void ChessGame::startGraphicUI() {}
void ChessGame::displaySelectedChessPieceValidMoves() const {}
void ChessGame::displayCurrentPlayerCheck() const {}
void ChessGame::updateCastlingGUI() const {}



/**************
 * Console UI *
 **************/

void ChessGame::startConsoleUI() {
    do {
        displayChessBoardConsole();
        cout << ((currentPlayer == WHITE)? "White" : "Black") << "'s Turn." << endl;

        int row, col;
        char confirm;
        do {
            do {
                do {
                    cout << "Select your Chess Piece (col, row): ";
                    cin >> col >> row; col -= 1; row -=1;
                    if ((row < 0) || (row >= 8) || (col < 0) || (col >= 8)) continue;

                    if ((chessBoard[row][col] != nullptr) && (chessBoard[row][col]->player != currentPlayer)) {
                        selectedChessPiece = nullptr;
                    }
                    else {
                        selectedChessPiece = chessBoard[row][col];
                    }
                    calculateValidMoves(selectedChessPiece, selectedChessPieceValidMoves);
                } while (selectedChessPiece == nullptr);
                cout << endl;
                displaySelectedChessPieceValidMovesConsole();

                cout << "Confirm selection? (Y/N) ";
                cin >> confirm;
            } while ((confirm != 'Y') && (confirm != 'y'));

            cout << "Make your Move (col, row): ";
            cin >> col >> row; col -= 1; row -=1;
            cout << endl;
        } while ((row < 0) || (row >= 8) || (col < 0) || (col >= 8) || !selectedChessPieceValidMoves[row][col]);
        ChessPiece* occupyingChessPiece = selectedChessPiece->move(row, col);
        delete occupyingChessPiece;

        selectedChessPiece = nullptr;
        fill_n(&selectedChessPieceValidMoves[0][0], 64, false); // Reset all to false.
        currentPlayer = ((currentPlayer == WHITE)? BLACK : WHITE);
        getPlayerKing(currentPlayer)->updateCheck();
    } while (hasValidMoves(currentPlayer));

    displayChessBoardConsole();
    if (getPlayerKing(currentPlayer)->isCheck()) {
        cout << ((currentPlayer == WHITE)? "White" : "Black") << " Checkmate! " << ((currentPlayer == WHITE)? "Black" : "White") << " wins!" << endl;
    }
    else {
        cout << "Stalemate!" << endl;
    }
}

void ChessGame::displayChessBoardConsole() const {
    cout << " |---|---|---|---|---|---|---|---|\n";
    for (int row = 7; row >= 0; row--) {
        cout << row + 1;
        for (int col = 0; col < 8; col++) {
            cout << "|";

            if (chessBoard[row][col] == nullptr) {
                cout << "   ";
            }
            else {
                if ((chessBoard[row][col] == getPlayerKing(currentPlayer)) && getPlayerKing(currentPlayer)->isCheck()) {
                    cout << "!" << chessBoard[row][col]->getImage() << "!";
                }
                else {
                    cout << " " << chessBoard[row][col]->getImage() << " ";
                }
            }
        }
        cout << "|\n";
        cout << " |---|---|---|---|---|---|---|---|\n";
    }
    cout << " | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |\n";
    cout << endl;
}

void ChessGame::displaySelectedChessPieceValidMovesConsole() const {
    cout << " |---|---|---|---|---|---|---|---|\n";
    for (int row = 7; row >= 0; row--) {
        cout << row + 1;
        for (int col = 0; col < 8; col++) {
            cout << "|";
            if (chessBoard[row][col] == nullptr) {
                if (selectedChessPieceValidMoves[row][col]) {
                    cout << "< >";
                }
                else {
                    cout << "   ";
                }
            }
            else {
                if (selectedChessPieceValidMoves[row][col] || ((row == selectedChessPiece->getRow()) && (col == selectedChessPiece->getCol()))) {
                    cout << "<" << chessBoard[row][col]->getImage() << ">";
                }
                else if ((chessBoard[row][col] == getPlayerKing(currentPlayer)) && getPlayerKing(currentPlayer)->isCheck()) {
                    cout << "!" << chessBoard[row][col]->getImage() << "!";
                }
                else {
                    cout << " " << chessBoard[row][col]->getImage() << " ";
                }
            }
        }
        cout << "|\n";
        cout << " |---|---|---|---|---|---|---|---|\n";
    }
    cout << " | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |\n";
    cout << endl;
}
