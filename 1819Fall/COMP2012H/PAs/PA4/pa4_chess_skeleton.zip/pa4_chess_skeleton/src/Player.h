#ifndef PLAYER_H_
#define PLAYER_H_

enum Player {WHITE, BLACK};

#endif /* PLAYER_H_ */
