#ifndef STOCK_TEST_H
#define STOCK_TEST_H

void task1();
void task2();
void task3();
void task4();
void selfTest();

#endif //STOCK_TEST_H
